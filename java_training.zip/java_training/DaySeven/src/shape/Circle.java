package shape;

public class Circle extends Shape{
	
	public Circle(double width, double length) {
		super(width, length);
		// TODO Auto-generated constructor stub
	}

	public Circle(double width) {
		super(width);
		// TODO Auto-generated constructor stub
	}

	public double area() {
		System.out.println("Circle area:");
		return Math.PI*getWidth()*getLength();
	}
	

}