package shape;

public class Cylinder extends Shape {

	private double height;
	public Cylinder(double width, double height) {
		super(width);
		this.height = height;
		
		// TODO Auto-generated constructor stub
	}
	
	public double area() {
		System.out.println("Cylinder area called");
		return 4/3+3.14*width*height;
	}

}
