package shape;

public class Sphere extends Circle{

	public Sphere(double width, double length) {
		super(width, length);
	}

	public Sphere(double width) {
		super(width);
	}
	public double area() {
		System.out.println("Sphere area:");
		return 4*Math.PI*getWidth()*getLength();
	}

}