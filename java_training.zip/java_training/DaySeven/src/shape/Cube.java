package shape;

public class Cube extends Square{

	public Cube(double width, double length) {
		super(width, length);
	}

	public Cube(double width) {
		super(width);
	}
	public double area() {
		System.out.println("Cube area:");

		return 6*getWidth()*getWidth();
	}

}