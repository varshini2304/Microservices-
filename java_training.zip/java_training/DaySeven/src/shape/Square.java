package shape;

public class Square extends Shape{

	public Square(double width, double length) {
		super(width, length);
		// TODO Auto-generated constructor stub
	}

	public Square(double width) {
		super(width);
		// TODO Auto-generated constructor stub
	}
	
	public double area() {
		System.out.println("square area called");
		return width*width;
	}

}
