package shape;

public class Triangle extends Shape{
	
	public Triangle(double width, double length) {
		super(width, length);
		// TODO Auto-generated constructor stub
	}

	public Triangle(double width) {
		super(width);
		// TODO Auto-generated constructor stub
	}

	public double area() {
		System.out.println("Triangle area:");
		return 0.5*getWidth()*getLength();
	}

}