package shape;

public class Exio {
	public void sampo(int ...is) {
		for(int i:is) {
			System.out.print(" "+i);
			
		}
	}

	public static void main(String[] args) {
            Shape shape =new Triangle(20,30);
            System.out.println(shape.area());
            
            shape =new Circle(20);
            System.out.println(shape.area());
            
            shape=new Square(20,50);
            System.out.println(shape.area());
            
            shape=new Cylinder(20,50);
            System.out.println(shape.area());
            
            shape=new Sphere(10);
            System.out.println(shape.area());
            
            shape=new Cube(15);
            System.out.println(shape.area());
            
            shape=new Cuboid(10,10,4);
            System.out.println(shape.area());
            
            
           
             
            
 //           Exio ex =new Exio();
//            ex.sampo(22);
//            ex.sampo(22,33,55);
            
	}

}