package shape;

public class Cuboid extends Square{
    private double height;
	public Cuboid(double width, double length,double height) {
		super(width, length);
		this.height=height;
	}

	public Cuboid(double width) {
		super(width);
	}
	public double area() {
		System.out.println("Cuboid area:");
		return 2*((getLength()*getWidth())+(getWidth()*this.height)+(getLength()*this.height));
	}
	

}