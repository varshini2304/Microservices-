package first;

public class Third {

	public static void main(String[] args) {
              String str = "This is an immutable object...";
              char[] rev = str.toCharArray();
              
              StringBuilder stb = new StringBuilder(str);
              System.out.println(stb);                         
              StringBuffer sbf = new StringBuffer(str);
              System.out.println(sbf);
              System.out.println(sbf.reverse());
              System.out.println(sbf.capacity());
              sbf.append("false bells keep ringing");
              System.out.println(sbf.capacity());
              System.out.println(sbf);
              String st = "one";
              String st2 = "two";

                            
	}

}