package first;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;

public class Second {
	public static void main(String[] args) {
		LocalDate date = LocalDate.of(2020, 10,10);
		LocalDate date1 = LocalDate.of(2021, 1,15);
		LocalTime time = LocalTime.of(11,30,15);
		LocalTime time2 = LocalTime.of(15,40,25);
		LocalDateTime  dt = LocalDateTime.of(date,time);
		System.out.println(date);
		System.out.println(date1);
		System.out.println(time);
		System.out.println(time2);
		
		Duration duration = Duration.between(date, date1);
		System.out.println(duration.toDays());
		System.out.println(duration.toHours());
		
		Duration duration2 = Duration.between(time, time2);
		System.out.println(duration2.toDays());
        System.out.println(duration2.toHours());
        
        


		
		Period period = Period.between(date, date1);
	    System.out.println(period.getDays());
	    
	    //period is applicable with date only
	  

		

		
		
	}

}