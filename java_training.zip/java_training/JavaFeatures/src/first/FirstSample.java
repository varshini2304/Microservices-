package first;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class Item{
	private int id;
	private String name;
	private int quantity;
	private double price;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Item(int id, String name, int quantity, double price) {
		super();
		this.id = id;
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Item [id=" + id + ", name=" + name + ", quantity=" + quantity + ", price=" + price + "]";
	}
	public Item() {
		super();
	}
}

public class FirstSample {
	public static void main(String[] args) {
		List<String> mylist = Arrays.asList("one","two","three","","four","five");
		Stream<String> stro = mylist.stream();
		System.out.println(stro);
//		stro.map(e->e).filter(e->e.startsWith("o")).forEach(System.out::println);
//		stro.map(e->e).filter(e->e.endsWith("o")).forEach(System.out::println);
		stro.map(e->e).filter(e->e.startsWith("t")).forEach(y->System.out.println(y.toUpperCase()));
		stro = mylist.stream();
		System.out.println(stro.count());
		stro = mylist.stream();

		String lee = stro.collect(Collectors.joining("!"));
		System.out.println(lee);
		
	}

}
