package assignmentCopyIfelse;

public class Sony extends TeleVision {
    public String model;
    public int inch;
	private String type;
	private String clarity;

    public Sony(int quantity, String type, String clarity, String model, int inch) {
        super(quantity, type, clarity);
        this.model = model;
        this.inch = inch;
        this.pname = "Sony";
        this.price = 111500;
        this.productType = "SONY";
    }

    @Override
    public String getProduct() {
        return super.getProduct() + inch + " inches";
    }



    @Override
    public Product copy(int newQuantity) {
        return new Sony(newQuantity, this.type, this.clarity, this.model, this.inch);
    }

}
