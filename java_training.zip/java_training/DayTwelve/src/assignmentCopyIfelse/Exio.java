package assignmentCopyIfelse;

import java.util.Scanner;

public class Exio {
    private static int index = 0;
    private static Product[] cart = new Product[5];

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("\nWelcome to VS Store");
        System.out.println("==========================================");
        System.out.println("Categories Available:");
        System.out.println("1) Garments");
        System.out.println("2) Books");
        System.out.println("3) TVs");
        System.out.println("4) Mobiles");
        System.out.println("==========================================");

        String keepShopping = "y";
        while (keepShopping.equalsIgnoreCase("y")) {
            shopProducts(sc);
            System.out.print("\nWould you like to add more items? (y/n): ");
            keepShopping = sc.nextLine();
        }

        flushCart();
        Product.printBill(Inventory.getPurchasedProducts());

        System.out.println("\n***** THANK YOU FOR SHOPPING *****");
        sc.close();
    }

    private static void shopProducts(Scanner sc) {
        String more = "y";
        while (more.equalsIgnoreCase("y")) {
            if (index >= cart.length) {
                Inventory.addProduct(cart, index);
                index = 0;
                cart = new Product[5];
                System.out.println("\nCart buffer full → Added to Inventory!");
            }

            System.out.print("\nEnter your category choice: ");
            int catChoice = sc.nextInt();
            sc.nextLine();

            switch (catChoice) {
                case 1:
                    System.out.println("\n--- Garments ---");
                    for (int i = 0; i < ProductInterface.STOCK.length; i++) {
                        if (ProductInterface.STOCK[i] instanceof Garment ||
                            ProductInterface.STOCK[i] instanceof Shirt ||
                            ProductInterface.STOCK[i] instanceof Pant ||
                            ProductInterface.STOCK[i] instanceof ShortPant) {
                            int availableQty = StockManager.getAvailableQuantity(i);
                            System.out.println((i+1) + ") " + ProductInterface.STOCK[i].getProduct()
                                               + " [Stock: " + availableQty + "]");
                        }
                    }

                    System.out.print("Choose a product: ");
                    int gChoice = sc.nextInt(); sc.nextLine();

                    System.out.print("Enter qty: ");
                    int gQty = sc.nextInt(); sc.nextLine();

                    if (StockManager.isStockAvailable(gChoice-1, gQty)) {
                        Product gSelected = ProductInterface.STOCK[gChoice-1];
                        cart[index++] = copyProduct(gSelected, gQty);

                        StockManager.reduceStock(gChoice-1, gQty);
                        System.out.println("Added to cart and stock updated!");
                    } else {
                        System.out.println(" Insufficient stock! Available: " +
                                         StockManager.getAvailableQuantity(gChoice-1));
                    }
                    break;

                case 2:
                    System.out.println("\n--- Books ---");
                    for (int i = 0; i < ProductInterface.STOCK.length; i++) {
                        if (ProductInterface.STOCK[i] instanceof Book ||
                            ProductInterface.STOCK[i] instanceof Novel ||
                            ProductInterface.STOCK[i] instanceof Thriller ||
                            ProductInterface.STOCK[i] instanceof Classic) {
                            int availableQty = StockManager.getAvailableQuantity(i);
                            System.out.println((i+1) + ") " + ProductInterface.STOCK[i].getProduct()
                                               + " [Stock: " + availableQty + "]");
                        }
                    }

                    System.out.print("Choose a product: ");
                    int choice = sc.nextInt(); sc.nextLine();

                    System.out.print("Enter qty: ");
                    int qty = sc.nextInt(); sc.nextLine();

                    if (StockManager.isStockAvailable(choice-1, qty)) {
                        Product selected = ProductInterface.STOCK[choice-1];
                        cart[index++] = copyProduct(selected, qty);

                        StockManager.reduceStock(choice-1, qty);
                        System.out.println("Added to cart and stock updated!");
                    } else {
                        System.out.println(" Insufficient stock! Available: " +
                                         StockManager.getAvailableQuantity(choice-1));
                    }
                    break;

                case 3:
                    System.out.println("\n--- TVs ---");
                    for (int i = 0; i < ProductInterface.STOCK.length; i++) {
                        if (ProductInterface.STOCK[i] instanceof TeleVision ||
                            ProductInterface.STOCK[i] instanceof OnePlus ||
                            ProductInterface.STOCK[i] instanceof Sony) {
                            int availableQty = StockManager.getAvailableQuantity(i);
                            System.out.println((i+1) + ") " + ProductInterface.STOCK[i].getProduct()
                                               + " [Stock: " + availableQty + "]");
                        }
                    }

                    System.out.print("Choose a product: ");
                    int tvChoice = sc.nextInt(); sc.nextLine();

                    System.out.print("Enter qty: ");
                    int tvQty = sc.nextInt(); sc.nextLine();

                    if (StockManager.isStockAvailable(tvChoice-1, tvQty)) {
                        Product tvSelected = ProductInterface.STOCK[tvChoice-1];
                        cart[index++] = copyProduct(tvSelected, tvQty);

                        StockManager.reduceStock(tvChoice-1, tvQty);
                        System.out.println("Added to cart and stock updated!");
                    } else {
                        System.out.println(" Insufficient stock! Available: " +
                                         StockManager.getAvailableQuantity(tvChoice-1));
                    }
                    break;

                case 4:
                    System.out.println("\n--- Mobiles ---");
                    for (int i = 0; i < ProductInterface.STOCK.length; i++) {
                        if (ProductInterface.STOCK[i] instanceof Mobile ||
                            ProductInterface.STOCK[i] instanceof buttonPhone ||
                            ProductInterface.STOCK[i] instanceof SmartPhone ||
                            ProductInterface.STOCK[i] instanceof Ipad) {
                            int availableQty = StockManager.getAvailableQuantity(i);
                            System.out.println((i+1) + ") " + ProductInterface.STOCK[i].getProduct()
                                               + " [Stock: " + availableQty + "]");
                        }
                    }

                    System.out.print("Choose a product: ");
                    int mChoice = sc.nextInt(); sc.nextLine();

                    System.out.print("Enter qty: ");
                    int mQty = sc.nextInt(); sc.nextLine();

                    if (StockManager.isStockAvailable(mChoice-1, mQty)) {
                        Product mSelected = ProductInterface.STOCK[mChoice-1];
                        cart[index++] = copyProduct(mSelected, mQty);

                        StockManager.reduceStock(mChoice-1, mQty);
                        System.out.println("✓ Added to cart and stock updated!" );
                    } else {
                        System.out.println(" Insufficient stock! Available: " +
                        StockManager.getAvailableQuantity(mChoice-1));
                    }
                    break;
            }

            System.out.print("Add more? (y/n): ");
            more = sc.nextLine();
        }
    }

    private static Product copyProduct(Product stockItem, int qty) {
        return stockItem.copy(qty);
    }

    private static void flushCart() {
        if (index > 0) {
            Inventory.addProduct(cart, index);
            index = 0;
            cart = new Product[5];
        }
    }

}
