package assignmentCopyIfelse;

public class Mobile extends Product {
    public String brand;
    public String model;

    public Mobile(int quantity, String brand, String model) {
        super(quantity, "Mobile", 20000.00, 0.08, "MOBILE"); // default 8%
        this.brand = brand;
        this.model = model;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " " + brand + " " + model;
    }
}
