package assignmentCopyIfelse;

public class Thriller extends Novel {

    public Thriller(int quantity, String author, String year, String language, String hardcover) {
        super(quantity, author, year, language, hardcover);
        this.pname = "Thriller";
        this.price = 1250;
        this.productType = "THRILLER";
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " Thriller novel";
    }

    @Override
    public Product copy(int newQuantity) {
        return new Thriller(newQuantity, this.author, this.year, this.language, this.hardcover);
    }
}
