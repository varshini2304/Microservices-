package assignmentCopyIfelse;

public class StockManager {
    private static Product[] currentStock;

    static {
        initializeStock();
    }

    public static void initializeStock() {
        Product[] originalStock = ProductInterface.STOCK;
        currentStock = new Product[originalStock.length];

        for (int i = 0; i < originalStock.length; i++) {
            currentStock[i] = originalStock[i].copy(originalStock[i].getQuantity());
        }
    }

    public static Product[] getCurrentStock() {
        return currentStock;
    }

    public static Product getStockItem(int index) {
        if (index >= 0 && index < currentStock.length && currentStock[index] != null) {
            return currentStock[index];
        }
        return null;
    }

    public static boolean isStockAvailable(int stockIndex, int requestedQuantity) {
        Product stockItem = getStockItem(stockIndex);
        return stockItem != null && stockItem.getQuantity() >= requestedQuantity;
    }

    public static boolean reduceStock(int stockIndex, int quantityToReduce) {
        Product stockItem = getStockItem(stockIndex);
        if (stockItem != null && stockItem.getQuantity() >= quantityToReduce) {
            int newQuantity = stockItem.getQuantity() - quantityToReduce;
            stockItem.updateQuantity(newQuantity);
            return true;
        }
        return false;
    }

    public static int getAvailableQuantity(int stockIndex) {
        Product stockItem = getStockItem(stockIndex);
        return stockItem != null ? stockItem.getQuantity() : 0;
    }

    public static void displayStockStatus() {
        System.out.println("\n=== CURRENT STOCK STATUS ===");
        for (int i = 0; i < currentStock.length; i++) {
            if (currentStock[i] != null) {
                System.out.println((i+1) + ") " + currentStock[i].getProduct() +
                                 " [Available: " + currentStock[i].getQuantity() + "]");
            }
        }
        System.out.println("============================");
    }

    public static void resetStock() {
        initializeStock();
    }
}
