package assignmentCopyIfelse;

public class ShortPant extends Pant {

    public ShortPant(int quantity, String pname, String color, String material, String type, int size) {
        super(quantity, pname, color, material, type, size);
        this.price = 1650;
        this.pname = "Short Pant";
        this.productType = "SHORTPANT";
    }

    @Override
    public String getProduct() {
        return super.getProduct() + "Short Pant";
    }

    @Override
    public Product copy(int newQuantity) {
        return new ShortPant(newQuantity, this.pname, this.color, this.material, this.type, this.size);
    }

}
