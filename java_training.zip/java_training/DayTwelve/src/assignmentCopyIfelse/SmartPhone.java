package assignmentCopyIfelse;

public class SmartPhone extends Mobile {

    public int simport;
	private String storage;
	private String ram;

    public SmartPhone(int quantity, String storage, String ram, int simport) {
        super(quantity, storage, ram);
        this.price = 18000;
        this.simport = simport;
        this.pname = "SmartPhone";
        this.productType = "SMARTPHONE";
    }

    @Override
    public String getProduct() {
        return super.getProduct() + simport + " SIM port(s)";
    }


    @Override
    public Product copy(int newQuantity) {
        return new SmartPhone(newQuantity, this.storage, this.ram, this.simport);
    }

}
