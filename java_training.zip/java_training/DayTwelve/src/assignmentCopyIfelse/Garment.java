package assignmentCopyIfelse;

public class Garment extends Product {

    public String color;
    public String material;

    public Garment(int quantity, String color, String material) {
        super(quantity, "Garment", 1400, 0.25, "GARMENT");
        this.color = color;
        this.material = material;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " " + color + " color " + material;
    }



    @Override
    public Product copy(int newQuantity) {
        return new Garment(newQuantity, this.color, this.material);
    }
}
