package assignmentCopyIfelse;

public class buttonPhone extends Mobile {

    public int simport;
	private String ram;
	private String storage;

    public buttonPhone(int quantity, String storage, String ram, int simport) {
        super(quantity, storage, ram);
        this.price = 18000;
        this.pname = "Button Phone";
        this.productType = "BUTTONPHONE";
        this.simport = simport;
    }

    @Override
    public String getProduct() {
        return super.getProduct() +
                simport + " SIM port(s)";
    }



    @Override
    public Product copy(int newQuantity) {
        return new buttonPhone(newQuantity, this.storage, this.ram, this.simport);
    }

}
