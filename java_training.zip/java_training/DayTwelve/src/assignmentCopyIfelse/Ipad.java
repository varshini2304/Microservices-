package assignmentCopyIfelse;

public class Ipad extends SmartPhone {

    public int camera;
    private String storage;
    private String ram;

    public Ipad(int quantity, String storage, String ram, int simport, int camera) {
        super(quantity, storage, ram, simport);
        this.price = 29000;
        this.pname = "Ipad";
        this.productType = "IPAD";
        this.camera = camera;
    }

    @Override
    public String getProduct() {
        System.out.print(super.getProduct());
        return "" + camera + "camera's";
    }

    @Override
    public Product copy(int newQuantity) {
        return new Ipad(newQuantity, this.storage, this.ram, this.simport, this.camera);
    }

}
