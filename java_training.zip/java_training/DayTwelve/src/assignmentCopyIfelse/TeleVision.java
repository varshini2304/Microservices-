package assignmentCopyIfelse;

public class TeleVision extends Product {
    public String brand;
    public String size;

    public TeleVision(int quantity, String brand, String clarity) {
        super(quantity, "TV", 35000.00, 0.07, "TELEVISION");
        this.brand = brand;
        this.size = clarity;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " " + brand + " " + size + " inch";
    }
}
