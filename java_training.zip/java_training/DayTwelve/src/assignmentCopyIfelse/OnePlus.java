package assignmentCopyIfelse;

public class OnePlus extends TeleVision {

    public String model;
    public int inch;
	private String type;
	private String clarity;

    public OnePlus(int quantity, String type, String clarity, String model, int inch) {
        super(quantity, type, clarity);
        this.model = model;
        this.inch = inch;
        this.pname = "OnePlus";
        this.price = 111500;
        this.productType = "ONEPLUS";
    }

    @Override
    public String getProduct() {
        return super.getProduct() +
               " | OnePlus TV ("+inch + " inch screen)";
    }



    @Override
    public Product copy(int newQuantity) {
        return new OnePlus(newQuantity, this.type, this.clarity, this.model, this.inch);
    }

}
