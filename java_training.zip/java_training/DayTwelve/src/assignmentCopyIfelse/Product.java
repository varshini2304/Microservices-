package assignmentCopyIfelse;

public class Product implements ProductInterface {
    public long pid;
    public int quantity;
    public String pname;
    public double price;
    private double percen;
    protected String productType;

    public Product(int quantity, String pname, double price) {
        this(quantity, pname, price, 0.10, "DEFAULT");
    }

    public Product(int quantity, String pname, double price, double percen) {
        this(quantity, pname, price, percen, "DEFAULT");
    }

    public Product(int quantity, String pname, double price, double percen, String productType) {
        this.pid = generatePid();
        this.quantity = (quantity > 0) ? quantity : 1;
        this.pname = pname;
        this.price = price;
        this.percen = percen;
        this.productType = productType;
    }

    private long generatePid() {
        return Math.round(Math.random() * 10000);
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getPname() {
        return pname;
    }

    public String getProduct() {
        return "'" + pname.toUpperCase() + "'";
    }

    public void setPercen(double percen) {
        this.percen = percen;
    }

    public double getPercen() {
        return this.percen;
    }

    @Override
    public final double getDiscount(double subtotal) {
        if (productType.equals("BOOK")) {
            return quantity >= 10 ? subtotal * 0.15 : subtotal * percen;
        } else if (productType.equals("MOBILE")) {
            return quantity >= 2 ? subtotal * 0.12 : subtotal * percen;
        } else if (productType.equals("GARMENT")) {
            return quantity >= 10 ? subtotal * 0.40 : subtotal * percen;
        } else if (productType.equals("SHIRT")) {
            return quantity >= 4 ? subtotal * 0.30 : subtotal * percen;
        } else if (productType.equals("SMARTPHONE")) {
            return quantity >= 3 ? subtotal * 0.20 : subtotal * percen;
        } else if (productType.equals("TELEVISION")) {
            return quantity >= 2 ? subtotal * 0.10 : subtotal * percen;
        } else if (productType.equals("PANT")) {
            return quantity >= 2 ? subtotal * 0.35 : subtotal * percen;
        } else if (productType.equals("BUTTONPHONE")) {
            return quantity >= 3 ? subtotal * 0.20 : subtotal * percen;
        } else if (productType.equals("NOVEL")) {
            return quantity >= 5 ? subtotal * 0.40 : (quantity >= 3 ? subtotal * 0.25 : subtotal * percen);
        } else if (productType.equals("CLASSIC")) {
            return quantity >= 5 ? subtotal * 0.40 : (quantity >= 3 ? subtotal * 0.25 : subtotal * percen);
        } else if (productType.equals("IPAD")) {
            return quantity >= 2 ? subtotal * 0.35 : subtotal * percen;
        } else if (productType.equals("ONEPLUS")) {
            return quantity >= 2 ? subtotal * 0.35 : subtotal * percen;
        } else if (productType.equals("SHORTPANT")) {
            return quantity >= 4 ? subtotal * 0.30 : subtotal * percen;
        } else if (productType.equals("SONY")) {
            return quantity >= 3 ? subtotal * 0.20 : subtotal * percen;
        } else if (productType.equals("THRILLER")) {
            return quantity >= 5 ? subtotal * 0.40 : (quantity >= 3 ? subtotal * 0.25 : subtotal * percen);
        } else {
            return subtotal * percen;
        }
    }

    @Override
    public int getProductTotal() {
        return (int) (price * quantity);
    }

    @Override
	public Product copy(int newQuantity) {
		return new Product(newQuantity, this.pname, this.price, this.percen);
	}

	public void updateQuantity(int newQuantity) {
		this.quantity = (newQuantity > 0) ? newQuantity : 1;
	}

    public static void printBill(Product[] purchased) {
        System.out.println(
                "======================================== FINAL BILL =============================================");
        System.out.printf("\n%-15s %-6s %-10s %-10s %-12s %-15s",
                "Product\t\t", "Qty", "Price", "Discount%", "Discount", "Price After Discount\n");

        double subtotal = 0;
        double totalDiscount = 0;

        for (Product p : purchased) {
            if (p != null) {
                double lineTotal = p.getPrice() * p.getQuantity();
                double discount = p.getDiscount(lineTotal);
                double afterDiscount = lineTotal - discount;

                double discountPercent = (lineTotal > 0) ? (discount / lineTotal) * 100 : 0;

                subtotal += lineTotal;
                totalDiscount += discount;

                System.out.printf("%-15s %-6d %-10.2f %-10.2f %-12.2f %-15.2f\n",
                        p.getProduct(), p.getQuantity(), lineTotal, discountPercent, discount, afterDiscount);
            }
        }

        // Calculate additional cart-level discount for orders >= 50,000
        double cartDiscount = 0;
        double cartDiscountPercent = 0;
        if (subtotal >= 50000) {
            cartDiscountPercent = 5.0; // 5% additional discount
            cartDiscount = subtotal * 0.05;
            totalDiscount += cartDiscount;
        }

        double netTotal = subtotal - totalDiscount;

        // Display subtotal and cart discount if applicable
        System.out.printf("%-15s %-6s %-10.2f %-10s %-12s %-15s",
                "SUBTOTAL", "", subtotal, "", "", "");
        System.out.println();

        if (cartDiscount > 0) {
            System.out.printf("%-15s %-6s %-10s %-10.2f %-12.2f %-15s",
                    "Final CART DISCOUNT", "", "", cartDiscountPercent, cartDiscount, "");
            System.out.println();
        }

        System.out.printf("%-15s %-6s %-10.2f %-10s %-12.2f %-15.2f",
                "TOTAL", "", subtotal, "", totalDiscount, netTotal);
        System.out.println("\n==============================================================");
        System.out.println("***** THANK YOU FOR SHOPPING *****");
        StockManager.displayStockStatus();
    }
}
