package assignmentCopyIfelse;

public class Shirt extends Garment {

    public String type;
    public String sleeve;

    public Shirt(int quantity, String color, String material, String type, String sleeve) {
        super(quantity, color, material);
        this.price = 700;
        this.pname = "Shirt";
        this.productType = "SHIRT";
        this.type = type;
        this.sleeve = sleeve;
    }

    @Override
    public String getProduct() {
        return super.getProduct() +"sleeve"+sleeve;
    }

    @Override
    public Product copy(int newQuantity) {
        return new Shirt(newQuantity, this.color, this.material, this.type, this.sleeve);
    }

}
