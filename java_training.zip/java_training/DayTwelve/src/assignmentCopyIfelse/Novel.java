package assignmentCopyIfelse;

public class Novel extends Book {
    public String language;
    public String hardcover;
	protected String year;

    public Novel(int quantity, String author, String year, String language, String hardcover) {
        super(quantity, author, year);
        this.pname = "Novel";
        this.price = 2300;
        this.productType = "NOVEL";
        this.language = language;
        this.hardcover = hardcover;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " " + language + " story";
    }



    @Override
    public Product copy(int newQuantity) {
        return new Novel(newQuantity, this.author, this.year, this.language, this.hardcover);
    }
}
