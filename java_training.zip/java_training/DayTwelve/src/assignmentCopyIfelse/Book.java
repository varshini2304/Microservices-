package assignmentCopyIfelse;

public class Book extends Product {
    public String author;
    public String genre;

    public Book(int quantity, String author, String genre) {
        super(quantity, "Book", 500.00, 0.05, "BOOK");
        this.author = author;
        this.genre = genre;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " by " + author + " (" + genre + ")";
    }


}
