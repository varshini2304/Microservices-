package assignmentCopyIfelse;

public class Pant extends Garment {

    public String type;
    public int size;

    public Pant(int quantity, String pname, String color, String material, String type, int size) {
        super(quantity, color, material);
        this.price = 1500;
        this.pname = "Garment Pant";
        this.productType = "PANT";
        this.type = type;
        this.size = size;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " | This pant is of size " + size + " and is a " + type + " wearable pant";
    }



    @Override
    public Product copy(int newQuantity) {
        return new Pant(newQuantity, this.pname, this.color, this.material, this.type, this.size);
    }

}
