package assignmentCopyIfelse;

public class Classic extends Novel {

	public Classic(int quantity, String author, String year, String language, String hardcover) {
		super(quantity, author, year, language, hardcover);
		this.price = 1200;
		this.pname = "Classic";
		this.productType = "CLASSIC";
	}

	public String getProduct() {
		super.getProduct();
		return "" + "";

	}

    @Override
    public Product copy(int newQuantity) {
        return new Classic(newQuantity, this.author, this.year, this.language, this.hardcover);
    }

}