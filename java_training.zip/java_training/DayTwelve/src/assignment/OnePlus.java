package assignment;

public class OnePlus extends TeleVision {

    public String model;
    public int inch;
	private String type;
	private String clarity;

    public OnePlus(int quantity, String type, String clarity, String model, int inch) {
        super(quantity, type, clarity);
        this.model = model;
        this.inch = inch;
        setPname("OnePlus");
        setPrice(111500);
    }

    @Override
    public String getProduct() {
        return super.getProduct() +
               " | OnePlus TV ("+inch + " inch screen)";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 2) {
            return subtotal * 0.35; 
        }
        return subtotal * getPercen();
    }

    @Override
    public Product copy(int newQuantity) {
        return new OnePlus(newQuantity, this.type, this.clarity, this.model, this.inch);
    }
}
