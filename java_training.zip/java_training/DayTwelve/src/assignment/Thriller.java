package assignment;

public class Thriller extends Novel {

    public Thriller(int quantity, String author, String year, String language, String hardcover) {
        super(quantity, author, year, language, hardcover);
        setPname("Thriller");
        setPrice(1250);
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " Thriller novel";
    }

	@Override
	public double getDiscount(double subtotal) {
	    if (getQuantity() >= 5) {
	        return subtotal * 0.40; 
	    } else if (getQuantity() >= 3) {
	        return subtotal * 0.25;
	    }
	    return subtotal * getPercen();
	}

    @Override
    public Product copy(int newQuantity) {
        return new Thriller(newQuantity, this.author, this.year, this.language, this.hardcover);
    }
}
