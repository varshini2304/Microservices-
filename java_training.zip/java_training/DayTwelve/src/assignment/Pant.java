package assignment;

public class Pant extends Garment {

    public String type;
    public int size;

    public Pant(int quantity, String pname, String color, String material, String type, int size) {
        super(quantity, color, material);
        setPrice(1500);
        setPname("Garment Pant");
        this.type = type;
        this.size = size;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + size + " and is a " + type + " wearable pant";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 2) {
            return subtotal * 0.35; 
        }
        return subtotal * getPercen(); 
    }

    @Override
    public Product copy(int newQuantity) {
        return new Pant(newQuantity, getPname(), this.color, this.material, this.type, this.size);
    }

}
