package assignment;

public class SmartPhone extends Mobile {

    public int simport;
	private String storage;
	private String ram;

    public SmartPhone(int quantity, String storage, String ram, int simport) {
        super(quantity, storage, ram);
        setPrice(18000);
        this.simport = simport;
        setPname("SmartPhone");
    }

    @Override
    public String getProduct() {
        return super.getProduct() + simport + " SIM port(s)";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 3) {
            return subtotal * 0.20; 
        }
        return subtotal * getPercen(); 
    }

    @Override
    public Product copy(int newQuantity) {
        return new SmartPhone(newQuantity, this.storage, this.ram, this.simport);
    }

}
