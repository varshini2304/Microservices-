package assignment;

public class Novel extends Book {
    public String language;
    public String hardcover;
	protected String year;

    public Novel(int quantity, String author, String year, String language, String hardcover) {
        super(quantity, author, year);
        setPname("Novel");
        setPrice(2300);
        this.language = language;
        this.hardcover = hardcover;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " " + language + " story";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 5) {
            return subtotal * 0.40;
        } else if (getQuantity() >= 3) {
            return subtotal * 0.25;
        }
        return subtotal * getPercen();
    }

    @Override
    public Product copy(int newQuantity) {
        return new Novel(newQuantity, this.author, this.year, this.language, this.hardcover);
    }
}
