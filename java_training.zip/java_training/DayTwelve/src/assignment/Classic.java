package assignment;

public class Classic extends Novel {

	public Classic(int quantity, String author, String year, String language, String hardcover) {
		super(quantity, author, year, language, hardcover);
		setPrice(1200);
		setPname("Classic");
	}

	public String getProduct() {
		super.getProduct();
		return "" + "";

	}

	@Override
	public double getDiscount(double subtotal) {
	    if (getQuantity() >= 5) {
	        return subtotal * 0.40;
	    } else if (getQuantity() >= 3) {
	        return subtotal * 0.25; 
	    }
	    return subtotal * getPercen(); 
	}

    @Override
    public Product copy(int newQuantity) {
        return new Classic(newQuantity, this.author, this.year, this.language, this.hardcover);
    }

}