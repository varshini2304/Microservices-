package assignment;

public class ShortPant extends Pant {

    public ShortPant(int quantity, String pname, String color, String material, String type, int size) {
        super(quantity, pname, color, material, type, size);
        setPrice(1650);
        setPname("Short Pant");
    }

    @Override
    public String getProduct() {
        return super.getProduct() + "Short Pant";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 4) {
            return subtotal * 0.30; 
        }
        return subtotal * getPercen();
    }

    @Override
    public Product copy(int newQuantity) {
        return new ShortPant(newQuantity, getPname(), this.color, this.material, this.type, this.size);
    }

}
