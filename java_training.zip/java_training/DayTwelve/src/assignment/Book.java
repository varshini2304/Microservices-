package assignment;

public class Book extends Product {
    public String author;
    public String genre;

    public Book(int quantity, String author, String genre) {
        super(quantity, "Book", 500.00, 0.05);
        this.author = author;
        this.genre = genre;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " by " + author + " (" + genre + ")";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 10) {
            return subtotal * 0.15;
        }
        return subtotal * getPercen();
    }
}
