package assignment;

public interface ProductInterface {

    void setPercen(double percen);

    double getPercen();

    default double calculateDiscount(double lineTotal, double percen) {
        return lineTotal * percen;
    }

    default double calculateFinalPrice(double lineTotal, double percen) {
        return lineTotal - calculateDiscount(lineTotal, percen);
    }

    double getDiscount(double subtotal);

    int getProductTotal();

    Product copy(int newQuantity);

    Product[] STOCK = {
            new Book(50, "Author1", "2024"),
            new Novel(30, "Author2", "2023", "English", "Hardcover"),
            new Thriller(20, "Author3", "2022", "Mystery", "HeroX"),
            new Classic(10, "Author4", "2021", "Victorian", "Poetic"),
            new Garment(40, "Red", "Cotton"),
            new Shirt(25, "Blue", "Linen", "Formal", "Full"),
            new Pant(15, "Levis", "Black", "Denim", "Jeans", 32),
            new ShortPant(20, "Nike", "Grey", "Polyester", "Sports", 30),
            new TeleVision(10, "LED", "4K"),
            new OnePlus(8, "OLED", "8K", "Y1S Pro", 55),
            new Sony(5, "QLED", "8K", "Bravia", 65),
            new Mobile(50, "128GB", "6GB"),
            new buttonPhone(20, "8GB", "1GB", 1),
            new SmartPhone(30, "256GB", "8GB", 2),
            new Ipad(10, "512GB", "16GB", 12, 64)
    };

}
