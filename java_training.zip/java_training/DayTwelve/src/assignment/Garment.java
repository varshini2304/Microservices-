package assignment;

public class Garment extends Product {

    public String color;
    public String material;

    public Garment(int quantity, String color, String material) {
        super(quantity, "Garment", 1400, 0.25);
        this.color = color;
        this.material = material;
    }

    @Override
    public String getProduct() {
        return super.getProduct() + " " + color + " color " + material;
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 10) {
            return subtotal * 0.40; 
        }
        return subtotal * getPercen(); 
    }

    @Override
    public Product copy(int newQuantity) {
        return new Garment(newQuantity, this.color, this.material);
    }
}
