package assignment;

public class Shirt extends Garment {

    public String type;
    public String sleeve;

    public Shirt(int quantity, String color, String material, String type, String sleeve) {
        super(quantity, color, material);
        setPrice(700);
        setPname("Shirt");
        this.type = type;
        this.sleeve = sleeve;
    }

    @Override
    public String getProduct() {
        return super.getProduct() +"sleeve"+sleeve;
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 4) {
            return subtotal * 0.30; 
        }
        return subtotal * getPercen(); 
    }

    @Override
    public Product copy(int newQuantity) {
        return new Shirt(newQuantity, this.color, this.material, this.type, this.sleeve);
    }

}
