package assignment;

public class Inventory {
    private static Product[] purchasedProducts = new Product[0];

    public static void addProduct(Product product) {
        if (product == null) return;

        for (int i = 0; i < purchasedProducts.length; i++) {
            if (purchasedProducts[i] != null &&
                purchasedProducts[i].getPname().equals(product.getPname())) {
                int newQuantity = purchasedProducts[i].getQuantity() + product.getQuantity();
                purchasedProducts[i].updateQuantity(newQuantity);
                return;
            }
        }

        Product[] newArr = new Product[purchasedProducts.length + 1];
        for (int i = 0; i < purchasedProducts.length; i++) newArr[i] = purchasedProducts[i];
        newArr[purchasedProducts.length] = product;
        purchasedProducts = newArr;
    }

    public static void addProduct(Product[] products) {
        if (products == null) return;
        for (Product p : products) if (p != null) addProduct(p);
    }

    public static void addProduct(Product[] products, int count) {
        if (products == null) return;
        for (int i = 0; i < count; i++) {
            if (products[i] != null) addProduct(products[i]);
        }
    }

    public static Product[] getPurchasedProducts() {
        return purchasedProducts;
    }

    public static void clearInventory() {
        purchasedProducts = new Product[0];
    }
}
