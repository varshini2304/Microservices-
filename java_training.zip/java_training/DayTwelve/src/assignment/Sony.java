package assignment;

public class Sony extends TeleVision {
    public String model;
    public int inch;
	private String type;
	private String clarity;

    public Sony(int quantity, String type, String clarity, String model, int inch) {
        super(quantity, type, clarity);
        this.model = model;
        this.inch = inch;
        setPname("Sony");
        setPrice(111500);
    }

    @Override
    public String getProduct() {
        return super.getProduct() + inch + " inches";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 3) {
            return subtotal * 0.20; // 20% discount for 3+ Sony TVs
        }
        return subtotal * getPercen(); // use the default percentage for smaller quantities
    }

    @Override
    public Product copy(int newQuantity) {
        return new Sony(newQuantity, this.type, this.clarity, this.model, this.inch);
    }

}
