package assignment;

public class Product implements ProductInterface {
    private long pid;
    private int quantity;
    private String pname;
    private double price;
    private double percen; 

    public Product(int quantity, String pname, double price) {
        this(quantity, pname, price, 0.10); 
    }

    public Product(int quantity, String pname, double price, double percen) {
        this.pid = generatePid();
        setQuantity(quantity);
        setPname(pname);
        setPrice(price);
        this.percen = percen;
    }

    public long getPid() {
        return pid;
    }

    public void setPid(long pid) {
        this.pid = pid;
    }

    public void setQuantity(int quantity) {
        this.quantity = (quantity > 0) ? quantity : 1;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    private long generatePid() {
        return Math.round(Math.random() * 10000);
    }

    public double getPrice() {
        return price;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getPname() {
        return pname;
    }

    public String getProduct() {
        return "'" + pname.toUpperCase() + "'";
    }

    @Override
    public void setPercen(double percen) {
        this.percen = percen;
    }

    @Override
    public double getPercen() {
        return this.percen;
    }

    @Override
    public double getDiscount(double subtotal) {
        return subtotal * percen; 
    }

    @Override
    public int getProductTotal() {
        return (int) (price * quantity);
    }

    @Override
	public Product copy(int newQuantity) {
		return new Product(newQuantity, getPname(), getPrice(), this.percen);
	}

	public void updateQuantity(int newQuantity) {
		setQuantity(newQuantity);
	}

    public static void printBill(Product[] purchased) {
        System.out.println(
                "======================================== FINAL BILL =============================================");
        System.out.printf("\n%-15s %-6s %-10s %-10s %-12s %-15s",
                "Product\t\t", "Qty", "Price", "Discount%", "Discount", "Price After Discount\n");

        double subtotal = 0;
        double totalDiscount = 0;

        for (Product p : purchased) {
            if (p != null) {
                double lineTotal = p.getPrice() * p.getQuantity();
                double discount = p.getDiscount(lineTotal);
                double afterDiscount = lineTotal - discount;

                double discountPercent = (lineTotal > 0) ? (discount / lineTotal) * 100 : 0;

                subtotal += lineTotal;
                totalDiscount += discount;

                System.out.printf("%-15s %-6d %-10.2f %-10.2f %-12.2f %-15.2f\n",
                        p.getProduct(), p.getQuantity(), lineTotal, discountPercent, discount, afterDiscount);
            }
        }

        double netTotal = subtotal - totalDiscount;
        System.out.printf("%-15s %-6s %-10.2f %-10s %-12.2f %-15.2f",
                "TOTAL", "", subtotal, "", totalDiscount, netTotal);
        System.out.println("\n==============================================================");
        System.out.println("***** THANK YOU FOR SHOPPING *****");
        StockManager.displayStockStatus();
    }
}
