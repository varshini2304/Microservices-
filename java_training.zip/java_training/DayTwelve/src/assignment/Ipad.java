package assignment;

public class Ipad extends SmartPhone {

    public int camera;
	private String storage;
	private String ram;

    public Ipad(int quantity, String storage, String ram, int simport, int camera) {
        super(quantity, storage, ram, simport);
        setPrice(29000);
        setPname("Ipad");
        this.camera = camera;
    }

    @Override
    public String getProduct() {
        System.out.print(super.getProduct());
        return "" + camera + "camera's";
    }

    @Override
    public double getDiscount(double subtotal) {
        if (getQuantity() >= 2) {
            return subtotal * 0.35; 
        }
        return subtotal * getPercen(); 
    }

    @Override
    public Product copy(int newQuantity) {
        return new Ipad(newQuantity, this.storage, this.ram, this.simport, this.camera);
    }

}
