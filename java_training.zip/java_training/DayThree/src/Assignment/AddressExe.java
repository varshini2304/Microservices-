package Assignment;

public class AddressExe {

	public static void main(String[] args) {
		Address add1 = new Address("vijaynagar","karnataka","CB shetty",572216,24);
		Person p1=new Person("varshini","female",88616450,add1);
		System.out.println(p1.getPerson());
	}
}
