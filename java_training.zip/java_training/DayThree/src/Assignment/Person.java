package Assignment;

public class Person {

	public String name;
	public String gender;
	private long phoneno;
	public Address address;
	
	
	public Person(String name,String gender,long phoneno,Address address)
	{
		this.name = name;
		this.gender = gender;
		this.phoneno=phoneno;
		this.address=address;
	}

	public String getPerson() {
		return name+" "+gender+" "+phoneno+" "+ address.getAddress();
	}
}
