package Assignment;

public class Address {
		public String area;
		public String street;
		public String state;
		public long pincode;
		public int doorno;
		public static String Address;
		

		public Address(String area,String state,String street,long pincode,int doorno)
		{
			this.state = state;
			this.area = area;
			this.doorno=doorno;
			this.pincode=pincode;
			this.street=street;
		}
		public String getAddress() {
			return state +" "+area+" "+doorno+" "+pincode+" "+street+" ";
		}
}
