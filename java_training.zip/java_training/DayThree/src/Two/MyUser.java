package Two;

public class MyUser {

	private long uid;
	private String username;
	private static int objcount;
	
	public MyUser(String username,String password) {
		this.username=username;
		this.uid=Math.round(Math.random()*100000);
		objcount++;
	}

	public long getUid() {
		return uid;
	}

	public String getUsername() {
		return username;
	}
	
	public String userMessage() {
		return " message from me "+"hai guys " + this.getUsername();
	}
	
	public int getObjectCount() {
		return objcount;
	}
}
