package Two;

public class Accesso {
	protected String pro = "protected";
	String defo = "default";
	public String pub = "Public";
}
