package Two;

public class MarkerExe {

	public static void main(String[] args) {
		Marker marker = new Marker();
		marker.setLength(20);
		marker.setWidth(300);
		System.out.println(marker.getPid());
		System.out.println(marker.getLength());
		System.out.println(marker.getWidth());
		marker.setLength(-20);
		marker.setWidth(3000);
		System.out.println(marker.getPid());
		System.out.println(marker.getLength());
		System.out.println(marker.getWidth());
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		System.out.println(Math.random());
		Marker marker1 = new Marker(20,30);
		marker1 = new Marker();
		marker1.setLength(-20);
		System.out.println(marker.getLength());
	}
}
