package Two;

public class Bulb {
	private int length;
	public void setLength(){
  }
public int getLength() {
return this.length;
}
}