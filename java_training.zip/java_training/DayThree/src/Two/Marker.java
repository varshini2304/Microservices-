package Two;

public class Marker {
	private int length;
	private int width;
	private long pid;
	
	public Marker() {
		this.pid = generatePid();
	}
	
	public Marker(int length, int width) {
		this.pid = generatePid();
		this.length=length;
		this.width=width;
	}
	
	public Marker(int length) {
		this.pid = generatePid();
		this.length=length;	
	}
	
	private long generatePid() {
		long lo =Math.round(Math.random()*100000);
		// TODO Auto-generated method stub
		return lo;
	}
	
	public long getPid() {
		return pid;
	}
	
	public void setPid(long pid) {
		this.pid = pid;
	}
	
	public int getLength() {
		return length;
	}
	
	public void setLength(int length) {
		this.length = length;
	}
	
	public int getWidth() {
		return width;
	}
	
	public void setWidth(int width) {
	    this.width = width;
	}

}