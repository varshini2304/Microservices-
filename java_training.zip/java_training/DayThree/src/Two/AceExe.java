package Two;

public class AceExe {
	public static void main(String[] args) {
		Accesso so = new Accesso();
		System.out.println(so.defo);
		System.out.println(so.pro);
		System.out.println(so.pub);
	}
}
