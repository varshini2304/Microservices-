package Two;

public class ExeOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyUser usso = new MyUser("one","two");
		System.out.println(usso.userMessage());
		System.out.println(usso.getObjectCount());
		MyUser usso1 = new MyUser("three","three three");
		System.out.println(usso1.userMessage());
		System.out.println(usso1.getObjectCount());
		MyUser usso2 = new MyUser("four","four four");
		System.out.println(usso2.userMessage());
		System.out.println(usso2.getObjectCount());
		MyUser usso3 = new MyUser("five","five five");
		System.out.println(usso3.userMessage());
		System.out.println(usso3.getObjectCount());
	}

}
