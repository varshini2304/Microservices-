package Twoa;

import Two.Marker;

public class Acess1 { 
	Two.Accesso so = new Two.Accesso();
	Marker marker = new Marker(20,30);
}
