package Twoa;

import Two.Accesso;

public class TestSpeci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Accesso so = new Accesso();
//		System.out.println(so.defo);
//		System.out.println(so.pro);
		System.out.println(so.pub);
	}

}
