package fin;

public class OtherWayThread implements Runnable {
	protected Thread t;
	public OtherWayThread() {
		t = new Thread(this);
		t.start();
	}

	public OtherWayThread(String stupid) {
		t = new Thread(this,stupid);
		t.start();
	}
	
	@Override
	public void run() {
		for (int i = 0; i < 5; i++) {
			System.out.println("hai this executes "+ i+t.getName());
		}
	}

}
