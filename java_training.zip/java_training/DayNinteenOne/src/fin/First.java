package fin;

public class First {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread());
		Thread.currentThread().setName("mahendra");
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread());
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
		System.out.println(Thread.currentThread());
		First first = new First();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("this will prints after 10 seconds");

	}
	
		public void funda() {
			try {
				wait();
			} catch (Exception ie) {
				ie.printStackTrace();
				}
		}
	

}
