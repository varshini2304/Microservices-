package fin;

public class Farmer extends Thread {
		private Basket basket;
		public Farmer(String name,Basket basket) {
			super(name);
			this.basket=basket;
		}
		
		@Override
		public void run() {
		super.run();
		System.out.println("Fill the basket");
		for (int i = 0; i < 15; i++) {
			
		synchronized (this.basket) {
			basket.setFruit(i);
			System.out.println("Filled the basket with fruit "+i);
			this.basket.ststeChange(true);
			this.basket.notify();
			
		}
			
		}
		
		System.out.println("Name is "+ getName());
		}
}
