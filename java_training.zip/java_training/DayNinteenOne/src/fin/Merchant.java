package fin;

public class Merchant extends Thread{
	private Basket basket;
	public Merchant(String name,Basket basket) {
		super(name);
		this.basket=basket;
	}
	
	@Override
	public void run() {
			
	for (int i = 0; i < 5; i++) {
		synchronized (this.basket) {
			int val = basket.getFruit();
			System.out.println("Bought fruit no"+i);
			this.basket.ststeChange(false);
			this.basket.notify();
		}
	}
	
	System.out.println("Name is "+ getName());
	}

}
