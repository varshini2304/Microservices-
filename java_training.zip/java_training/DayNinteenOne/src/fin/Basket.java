package fin;

public class Basket {

	private int fruit;
	private transient boolean flag = false;

	public synchronized int getFruit() {
		while(!flag) {
			try {
				wait();
			}catch(InterruptedException ie) {}
		}
		return fruit;
	}

	public synchronized void setFruit(int fruit) {
		while(flag) {
			try {
				wait();
			}
			catch (InterruptedException ie) {
			}
		this.fruit = fruit;
	}
	}
	
	
	public void ststeChange(boolean flag) {
		this.flag= flag;
	}
}
