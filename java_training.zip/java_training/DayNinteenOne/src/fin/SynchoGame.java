package fin;

public class SynchoGame {

	public static void main(String[] args) {

		Basket basket = new Basket();
		Farmer farmer = new Farmer("Farmer", basket);
		Merchant merchant =new Merchant("Merchant", basket);
		
		try {
			farmer.join();	
			farmer.start();
			merchant.join();
			merchant.start();
			
		} catch (InterruptedException ie) {
			// TODO: handle exception
		}
		
	}

}
