package fin;

public class ExioTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		OtherWayThread tt = new OtherWayThread();
		OtherWayThread tt1 = new OtherWayThread("prasanna");
		MyThread me = new MyThread("Shashank");
		MyThread you = new MyThread("supriya");
		try {
			
			me.join();
			tt.t.join();
			you.join();
			tt1.t.join();
			
			me.start();tt.t.start();
			you.start();tt1.t.start();
		} catch (InterruptedException ie) {
		}
	}

}
