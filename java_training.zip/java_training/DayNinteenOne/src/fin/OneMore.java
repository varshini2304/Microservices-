package fin;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class OneMore {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable task = ()->{
			Thread.currentThread().setName("What a way to begin");
			for(int i =0;i<5;i++) {
				System.out.println("just it is " + Thread.currentThread().getName());
			}
		};

		Thread t = new Thread(task);
		t.start();
		
		//ExecutorService serv = Executors.newCachedThreadPool();
		
		ScheduledExecutorService serv = Executors.newScheduledThreadPool(1);
		
		try {
			serv.awaitTermination(10,TimeUnit.MINUTES);
			serv.execute(task);
			serv.shutdown();
			serv.isTerminated();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		finally {
			try {
				serv.shutdown();
			} catch (Exception e2) {
				System.out.println("bye");
			}
			
		}

	}

}
