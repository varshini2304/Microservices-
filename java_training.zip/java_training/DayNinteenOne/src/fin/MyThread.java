package fin;

public class MyThread extends Thread {

	public MyThread() {
		super();
	}

	public MyThread(Runnable target, String name) {
		super(target, name);
	}

	public MyThread(Runnable target) {
		super(target);
	}

	public MyThread(String name) {
		super(name);
	}

	@Override
	public void run() {
		super.run();
		for(int i=0;i<5;i++) {
			System.out.print("Mad cap is running this many times "+i);
			System.out.print(" Mad cap is "+ this.getName());
			System.out.print(" Mad cap is "+this.isAlive());
			System.out.println(" Mad cap is "+this.getState());
		}
	}
	
}
