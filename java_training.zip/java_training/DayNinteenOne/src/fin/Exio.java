package fin;

public class Exio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThread th = new MyThread("Varshini");
		th.start();
		MyThread th1 = new MyThread("habibi");
		th1.start();		
		MyThread th2 = new MyThread("welcome");
		th2.start();
		try {
			th.join();th1.join();th2.join();
		} catch (InterruptedException e) {
		}
		System.out.println(th.getName());
		System.out.println(th.getId());
		System.out.println(th.getPriority());
		System.out.println(th.isAlive());
		System.out.println(th.isDaemon());
		
		System.out.println(th1.getName());
		System.out.println(th1.getId());
		System.out.println(th1.getPriority());
		System.out.println(th1.isAlive());
		System.out.println(th1.isDaemon());
		
		System.out.println(th2.getName());
		System.out.println(th2.getId());
		System.out.println(th2.getPriority());
		System.out.println(th2.isAlive());
		System.out.println(th2.isDaemon());

	}

}
