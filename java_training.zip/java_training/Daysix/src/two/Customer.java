package two;

public class Customer {

}
