package two;
import some.Customer;

public class Exio extends some.Customer{
	
	private void syso() {
		System.out.println(privileged);
	}
	
	public static void main(String[] args) {
		three.Customer cc= new three.Customer();
		Customer customer = new Customer("guru","bramha",22,"male");
		System.out.println(customer.getAge());
		System.out.println(customer.getFirstName());
		two.Customer cus = new two.Customer();
		System.out.println(cus);
		System.out.println(customer);
	    System.out.println(cc);
	    Exio sss=new Exio();
	    sss.syso();
		//	System.out.println(customer.getPid());
		//	System.out.println(customer.domino);
		//	System.out.println(customer.privileged);
//		System.out.println(new two.customer());
	}
}
