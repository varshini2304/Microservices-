package three;

public class Customer {

}
