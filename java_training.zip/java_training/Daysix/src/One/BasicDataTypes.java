package One;

public class BasicDataTypes {
	public static void main(String[] args) {
		int a=20;
		char b='r';
		float f = 25.4f;
		double d=2229333545.485585854;
		long l=292_4512_5555L;
		boolean bol = true;
		byte byto = 127;
		short show = (short)35565;
		System.out.println(byto++);
		System.out.println((short)show++);
		System.out.println(byto++);
		System.out.println((short)show++);
		System.out.println(a++);
		System.out.println(b);
		System.out.println(f);
		System.out.println(d);
		System.out.println(l);
		System.out.println(10/3.0);
		System.out.println(bol);
		int y = 20;
		if(y<=20) {
			System.out.println("yes it is");
		}
		else {
			System.out.println("no it is not");
		}
	}
}
