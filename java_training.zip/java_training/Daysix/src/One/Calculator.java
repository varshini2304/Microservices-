package One;

public class Calculator {
	public void add(int a, int b) {
		System.out.println("addition of int and int "+(a+b));
	}
	public void substract(int a, int b) {
		System.out.println("substraction of int and int "+(a-b));
	}
	public void div(int a, int b) {
		System.out.println("division of int and int "+(a/b));
	}
	public void multip(int a, int b) {
		System.out.println("multiplication of int and int "+(a*b));
	}
	public void add(float a, int b) {
		System.out.println("addition of float and int "+(a+b));
	}
	public void substract(float a, int b) {
		System.out.println("substraction of float and int "+(a-b));
	}
	public void div(float a, int b) {
		System.out.println("division of float and int "+(a/b));
	}
	public void multip(float a, int b) {
		System.out.println("multiplication of float and int "+(a*b));
	}
	public void add(int a, float b) {
		System.out.println("addition of int and float "+(a+b));
	}
	public void substract(int a, float b) {
		System.out.println("substraction of int and float "+(a-b));
	}
	public void div(int a, float b) {
		System.out.println("division of int and float "+(a/b));
	}
	public void multip(int a, float b) {
		System.out.println("multiplication of int and float "+(a*b));
	}
	
	
	
}
