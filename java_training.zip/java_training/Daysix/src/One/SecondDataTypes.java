package One;

public class SecondDataTypes {

	public static void main(String[] args) {
		int a = -20;
		int b= -30;
		System.out.println((a*b+2)/(b-40));
		System.out.println((a+b));
		System.out.println("sum is :"+ (a+b));
		System.out.println(a>>32);
		System.out.println(b<<32);
		System.out.println(a>>>5);
		
	}
}
