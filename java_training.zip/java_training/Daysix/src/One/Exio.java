package One;

public class Exio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Table tt = new Table();
		tt.setLength(12);
		tt.setColor("green");
		tt.setHeight(10);
		System.out.println(tt.color);
		System.out.println(tt.getLength());
		System.out.println(tt.getHeight());
		tt.setHeight(0);
	}

}
