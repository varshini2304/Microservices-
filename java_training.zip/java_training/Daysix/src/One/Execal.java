package One;

public class Execal {
	public static void main(String[] args) throws ClassNotFoundException   {
		Calculator cal = new Calculator();
//		cal.add(23.5f, 20);
//		cal.div(20, 3.5f);
//		cal.multip(20, 30);
		int arr[] = {2,5,7,9,20};
		char crr[]= {'n','v'};
		System.out.println(arr);
		System.out.println(cal);
		System.out.println(crr);
		System.out.println(Class.forName("One.Execal"));
	}
}
