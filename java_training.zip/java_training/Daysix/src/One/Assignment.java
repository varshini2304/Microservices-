package One;

public class Assignment {

	public static void main(String[] args) {
		int a[]= {1,2,3,4,5};
		char b[]= {'A','E','I','O','U'};
		int a1=a.length;
		int b1=b.length;
		int addup[]=new int[a1+b1];
		for(int i=0;i<a1;i++) {
			addup[i]=a[i];
		}
		for(int i=0;i<b1;i++) {
			addup[a1+i]=(int)b[i];
		}
		for(int i=0;i<addup.length;i++) {
			System.out.println(addup[i]);
		}
	}
}
