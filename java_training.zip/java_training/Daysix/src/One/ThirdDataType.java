package One;

public class ThirdDataType {
	public static void main(String[] args) {
		//int a[][] = {{2,5,7,88},{-66,9,100,50}};
		//int a[][][] = new int [4][3][4];
		int b[][][] = new int[10][10][10];
		
		//b=a;
		//Systemout.println(a.length);
		//
		for (int j=0;j<b.length;j++){
			System.out.println("value is "+ b[j]);
		}
		int ab=200;
		//System.out.println(a);
		Integer into = new Integer(ab);
		System.out.println(into.intValue());
	}
}
