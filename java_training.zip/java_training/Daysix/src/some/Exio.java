package some;

public class Exio {

	public static void main(String[] args) {
		Customer customer = new Customer("guru","bramha",22,"male");
		System.out.println(customer.getAge());
		System.out.println(customer.getFirstName());
		System.out.println(customer.getPid());
		System.out.println(customer.domino);
		System.out.println(customer.privileged);
		//		Person p = customer;
//		System.out.println(p.getFirstName()+p.getLastName());
		
				
	}
}
