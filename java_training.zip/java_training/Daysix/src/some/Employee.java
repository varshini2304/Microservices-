package some;

class Employee extends Person{
	
	private String role;
	private double salary;
	public Employee() {
		super();
		this.salary=10000;
		this.role = "default";
		
		// TODO Auto-generated constructor stub
	}
	
	
	
	public Employee(String role, double salary,String mailId,long mobileNumber,Address address) {
		this(mailId,mobileNumber,address,role,salary);
	}



	private Employee(String mailId, long mobileNumber, Address address, String role,double salary) {
		super(mobileNumber, mailId, address);
		this.role=role;
		this.salary= salary;
	}
	public Employee(String firstName, String lastName, int age, String gender, long mobileNumber, String mailId,
			Address address) {
		super(firstName, lastName, age, gender, mobileNumber, mailId, address);
		// TODO Auto-generated constructor stub
	}
	public Employee(String firstName, String lastName, int age, String gender) {
		super(firstName, lastName, age, gender);
		// TODO Auto-generated constructor stub
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public double getSalary() {
		return salary;
	}
	
}