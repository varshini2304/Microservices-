package some;

public class Person {
	private long pid;
	private String firstName;
	private String lastName;
	private int age;
	private String gender;
	private long mobileNumber;
	private String mailId;
	private Address address;
	private long generatePid() {
		return Math.round(Math.random()*10000);
	}
	
	
	public Person() {
		super();
		this.pid=generatePid();
	}


	public Person(long mobileNumber, String mailId, Address address) {
		super();
		this.mobileNumber = mobileNumber;
		this.mailId = mailId;
		this.address = address;
		this.pid=generatePid();

	}


	public Person(String firstName, String lastName, int age, String gender, long mobileNumber, String mailId,
			Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.mobileNumber = mobileNumber;
		this.mailId = mailId;
		this.address = address;
		this.pid=generatePid();
	}


	public Person(String firstName, String lastName, int age, String gender) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.pid=generatePid();

	}
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public long getPid() {
		return pid;
	}
		
}

