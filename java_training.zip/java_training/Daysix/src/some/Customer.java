package some;

public class Customer extends Person{

	protected boolean privileged;
	String domino = "default fellow";
	
	
	public boolean isPrivileged() {
		return privileged;
	}

	public void setPrivileged(boolean privileged) {
		this.privileged = privileged;
	}

	public Customer() {
		super();
		
	}

	public Customer(long mobileNumber, String mailId, Address address) {
		super(mobileNumber, mailId, address);
	}

	public Customer(String firstName, String lastName, int age, String gender, long mobileNumber, String mailId,
			Address address) {
		super(firstName, lastName, age, gender, mobileNumber, mailId, address);
	}

	public Customer(String firstName, String lastName, int age, String gender) {
		super(firstName, lastName, age, gender);
	}
	
	
	
}


