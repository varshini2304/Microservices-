//package one;
//
//import one.DumboTwo.Funda;
//import one.DumboTwo.Funda.Junda;
//import one.DumboTwo.Funda.Junda.Gunda;
//import one.DumboTwo.Funda.Junda.Gunda.Chombu;
//
//public class ExeThree {
//	public static void main(String[] args) {
//		DumboTwo.Funda.Junda.Gunda.Chombu chombu= new Funda().new Junda().new Gunda().new Chombu();
//		chombu.thoothaChombu();
//		MewMew.Sombery boo = new MewMew.Sombery();
//	}
//	
//
//}
