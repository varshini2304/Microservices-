package one;

public interface Timer {
	interface Bhimer {
		class Chimer{
			private void showoff() {
				// TODO Auto-generated method stub
System.out.println("hai I'm here to displat");
			}
		}
		

	}


}
