package one;

public interface MewMew {
	static class Sombery{
		private class Bombery{
			
		}
	}
	class Pariwala{
		
	}

}
