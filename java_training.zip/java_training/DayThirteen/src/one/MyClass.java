package one;

public abstract class MyClass {
	
	public MyClass() {
	}

	protected abstract void doSomething();

}
