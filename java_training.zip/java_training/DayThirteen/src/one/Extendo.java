package one;

public class Extendo extends MyClass{
	protected void doSomething() {
		System.out.println("hey thi is extendo feloow!!!!");
	}
	
	private void pleaseSmileVinuth() {
		// TODO Auto-generated method stub
		System.out.println("hey this is new calaskjh");

	}
}
