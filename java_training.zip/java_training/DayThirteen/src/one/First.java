package one;

public interface First {

	public void grace();
}
