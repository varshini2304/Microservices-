package one;

public class ExeTwo {
	public static void main(String[] args ) {
		Outer outer = new Outer();
		Outer.Inner ino = new Outer().new Inner();
		ino.delay();
		Outer.Jim jimo = new Outer().new Implo();
		System.out.println(ino);
		System.out.println(jimo);
		System.out.println(ExeTwo.class.getClassLoader());
	}

}
