package one;
public class Classy {

	public Classy() {}
	static  class No{
		public void say() {
			System.out.println("hai this is not reachable");
		}
	}
	
	public void disp() {
		No no = new No();
		no.say();
		System.out.println("I'm called outer class fellow");
	}

}

