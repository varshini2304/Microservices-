package one;

public class Outer {
	
	class Inner{
		public void delay() {
			// TODO Auto-generated method stub
			System.out.println("it is here in the inner class");
		}
	}		
	interface Jim{
		void say();
		
	}
	class Implo implements Jim{
		@Override
		public void say() {
			// TODO Auto-generated method stub
			System.out.println("say it is louder here in the inner class");
		}
	}

}
