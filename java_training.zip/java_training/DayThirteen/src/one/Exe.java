package one;

public class Exe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass cla = new Extendo();
		First fir = new Implo();
		cla.doSomething();
		fir.grace();
		System.out.println(cla); 
		System.out.println(fir); 
		MyClass clo = new MyClass() {public void dosomething(){
			System.out.println("this is crazy one to see");
			}

		@Override
		protected void doSomething() {
			// TODO Auto-generated method stub
			
		}};
		System.out.println(clo); 
		First fo = new First() {
			@Override
			public void grace() {
				// TODO Auto-generated method stub
				System.out.println("this is even more crazy");
				}
			};
			
		System.out.println(fo); 

	}

}
