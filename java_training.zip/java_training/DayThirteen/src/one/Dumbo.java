package one;

public interface Dumbo {
	class Crazy{
		public void dudo() {
			// TODO Auto-generated method stub
			System.out.println("addododododododo");
		}
		class ChotuFellow{
			public void callo() {
				System.out.println("this is chotu inside the inner class of the interface");

			}
		}
	}

}
