package one;

public class DumboTwo {
	private String se = "Dd";

	class Funda{
		private String two = "toto";
		public void disp() {
			System.out.println(se);
			System.out.println(two);

		}
		class Junda{

			class Gunda{
				class Chombu{
					private String doda = "dodanna";

					public void thoothaChombu() {
						System.out.println("great fun here........"+se);
						System.out.println("fun here........"+doda);
						System.out.println("funno fun here........"+two);
						showman();
					}
				}
			}
		}
	}
	public void showman() {
		System.out.println(se);
		//System.out.println(two);
		//System.out.println(doda);
		System.out.println(new Funda().two);
		System.out.println(new Funda().new Junda().new Gunda().new Chombu().doda);

	}

}
