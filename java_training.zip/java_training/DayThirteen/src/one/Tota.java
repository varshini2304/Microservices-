package one;

import one.Classy.No;

public class Tota extends No {
	

}
