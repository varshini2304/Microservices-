package one;

public class Implo implements First {

	@Override
	public void grace() {
		System.out.println("this is it ");		
	}

	
}
