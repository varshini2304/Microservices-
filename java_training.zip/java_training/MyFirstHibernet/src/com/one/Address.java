package com.one;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
@Entity
public class Address {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long aid;
	@Column(length=5)
    private int doorNo;
	@Column(length=25)
    private String street;
	@Column(length=30)

	private String city;
	@Column(length=30)

	private String state;
	@Column(length=30)

	private String country;
	@Column(length=6)
     private int pincode;
	@OneToOne

	
	

	public long getAid() {
		return aid;
	}
	@Override
	public String toString() {
		return "Address [aid=" + aid + ", doorNo=" + doorNo + ", street=" + street + ", city=" + city + ", state="
				+ state + ", country=" + country + ", pincode=" + pincode + "]";
	}
	public void setAid(long aid) {
		this.aid = aid;
	}
	public int getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(int doorNo) {
		this.doorNo = doorNo;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

}
