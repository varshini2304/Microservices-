package com.one;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@SuppressWarnings("unused")
@Entity

public class Person {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private long pid;
	@Column(length=30)
	private String firstName;
	@Column(length=30)
    private String lastName;
	@Column(length=30)
    private String qualification;
	@Column(length=3)
    private int age;
	@Column(length=15)
    private String gender;
	@Column(length=10,name = "mobiNum",insertable = true,updatable=false)
    private long mobileNumber;
	
    @OneToOne(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
    @JoinColumn(name = "add_id")

    private Address address;
    @OneToOne(fetch = FetchType.EAGER)	
    @JoinColumn(name = "user_id")

    private User user;
    @Column(name = "stupid",precision =2)
    private double price;

    @Override
	public String toString() {
		return "Person [pid=" + pid + ", firstName=" + firstName + ", lastName=" + lastName + ", qualification="
				+ qualification + ", age=" + age + ", gender=" + gender + ", mobileNumber=" + mobileNumber
				+ ", address=" + address + ", user=" + user + "]";
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public long getPid() {
		return pid;
	}
	public void setPid(long pid) {
		this.pid = pid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	
}
