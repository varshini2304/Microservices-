package com.one.exe;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import com.prod.MyOrder;
public class HiboExeTwo {

	public static void main(String[] args) {
		  SessionFactory facto = null;
	         Configuration cfg = new Configuration();
//	         com.prod.Order order = new com.prod.Order();
//	         order.getItem();
	         facto = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
	         System.out.println(facto);
	}	

}
