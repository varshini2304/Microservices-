package com.one.exe;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Query;

import com.one.Address;
import com.one.Person;
import com.one.User;

public class HibExe {

	public static void main(String[] args) {
         SessionFactory facto = null;
         Configuration cfg = new Configuration();
         facto = cfg.configure("hibernate.cfg.xml").buildSessionFactory();
         System.out.println(facto);
//         Person person = new Person();
//         person.setFirstName("first");person.setLastName("last");
//         person.setAge(28);
//         person.setGender("male");person.setQualification("s.s.l.c");
//         person.setMobileNumber(1234563456);
//         Address address = new Address();
//         address.setDoorNo(3);
//         address.setStreet("shiva temple");
//         address.setCity("bangalore");
//
//         address.setState("karnataka");
//         address.setCountry("india");
//
//         address.setPincode(123456);
//         
//         User user = new User();
//         user.setUsername("varshini1");
//         user.setPassword("qwerwe");
//         user.setEmail("as@gg.com");
//
//
//         user.setType("user");
//         
//         person.setAddress(address);
//         person.setUser(user);
//         Session session = facto.openSession();
//         session.beginTransaction();
//         session.save(address);
//         session.save(user);
//         session.save(person);
//         session.getTransaction().commit();
//        @SuppressWarnings("deprecation")
//		Query<Person> query = session.createQuery("from Person");
//        List<Person> lee = query.list();
//        for(Person p:lee) {
//        	System.out.println(p);
//        	System.out.println(p.getAddress().getCity());
//        }
//         System.out.println("object saved successfully");
//         
         
         
	}

}
