package com.one;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity

public class Department {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	
	private long deptId;
	private String deptname;
//	@ManyToOne(targetEntity=Department.class)
//	private List<User> user;
//	public long getDeptId() {
//		return deptId;
//	}
//	public void setDeptId(long deptId) {
//		this.deptId = deptId;
//	}
//	public String getDeptname() {
//		return deptname;
//	}
//	public void setDeptname(String deptname) {
//		this.deptname = deptname;
//	}
//	public List<User> getUser() {
//		return user;
//	}
//	public void setUser(List<User> user) {
//		this.user = user;
//	}
	
	
	
	

}
