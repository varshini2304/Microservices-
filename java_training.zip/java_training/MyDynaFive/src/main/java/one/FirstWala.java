package one;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/FirstWala")
public class FirstWala extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter out = response.getWriter();
		response.setContentType("application/ms-word");
		out.println("<h1> Context wala"+getServletContext()+"</h1>");
		out.println("<h1> Request"+request+"</h1>");
		out.println("<h1> response"+response+"</h1>");
		
		HttpSession session = request.getSession();
		out.println("<h1>session"+session+"<h1>");
		out.println("<h1>servlet"+getServletName()+"<h1>");
		out.println("<h1> Config object"+getServletConfig()+"<h1>");
		out.println("<h1>"+request.getRequestDispatcher("FirstWala")+"<h1>");

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
